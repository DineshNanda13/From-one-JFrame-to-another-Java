/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package from1jframeto2jframe;

/**
 *
 * @author SONY INDIA
 */
public class From1JFrameTO2JFrame {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NewJFrame nf =new NewJFrame();
        nf.setVisible(true);
    }
    
}
